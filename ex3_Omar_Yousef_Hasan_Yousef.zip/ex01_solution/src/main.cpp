#include "FunctionCalculator.h"

#include <iostream>

int main()
{
    FunctionCalculator(std::cin, std::cout).run();
}
